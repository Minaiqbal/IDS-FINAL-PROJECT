from flask import Flask, request, render_template, redirect, url_for
import pandas as pd
import os

app = Flask(__name__)
DATA_PATH = os.path.join("data", "insurance_data.csv")

def initialize_data():
    """Initialize data file with demo policies if it doesn't exist or is empty"""
    if not os.path.exists("data"):
        os.makedirs("data", exist_ok=True)
    

    if not os.path.exists(DATA_PATH) or os.path.getsize(DATA_PATH) == 0:
        demo_data = {
            "Policy_No": ["1001", "1002", "1003", "1004"],
            "Name": ["Ahmed Ali", "Fatima Khan", "Hassan Malik", "Sara Hussain"],
            "CNIC": ["35201-1234567-1", "35202-9876543-2", "35203-5555555-3", "35204-7777777-4"],
            "Valid_Till": ["2025-12-31", "2026-06-30", "2027-03-15", "2025-09-20"],
            "Status": ["Active", "Active", "Expired", "Active"]
        }
        df = pd.DataFrame(demo_data)
        df.to_csv(DATA_PATH, index=False)

initialize_data()

def load_data():
    try:
        df = pd.read_csv(DATA_PATH)
        if df.empty:
            initialize_data()
            df = pd.read_csv(DATA_PATH)
        return df
    except Exception as e:
        print(f"Error loading data: {e}")
        initialize_data()
        return pd.read_csv(DATA_PATH)

def save_data(df):
    try:
        if not os.path.exists("data"):
            os.makedirs("data", exist_ok=True)
        df.to_csv(DATA_PATH, index=False)
        return True
    except Exception as e:
        print(f"Error saving data: {e}")
        return False
@app.route("/")
def home():
    return render_template("index.html")
@app.route("/get", methods=["POST"])
def chatbot_response():
    user_input = request.form["msg"].strip()
    df = load_data()
    if user_input.isdigit():
        match = df[df["Policy_No"].astype(str) == user_input]
        if not match.empty:
            row = match.iloc[0]
            return f" Policy Found!<br><b>Name:</b> {row['Name']}<br><b>CNIC:</b> {row['CNIC']}<br><b>Valid Till:</b> {row['Valid_Till']}<br><b>Status:</b> {row['Status']}"
        else:
            return " No policy found for this number."
    else:
        match = df[df["Name"].str.lower() == user_input.lower()]
        if not match.empty:
            row = match.iloc[0]
            return f" Policy Found!<br><b>Policy No:</b> {row['Policy_No']}<br><b>CNIC:</b> {row['CNIC']}<br><b>Valid Till:</b> {row['Valid_Till']}<br><b>Status:</b> {row['Status']}"
        return "Please enter a valid Policy Number or Name."
@app.route("/add", methods=["GET", "POST"])
def add_policy():
    if request.method == "POST":
        policy_no = request.form.get("policy_no", "").strip()
        name = request.form.get("name", "").strip()
        cnic = request.form.get("cnic", "").strip()
        valid_till = request.form.get("valid_till", "").strip()
        status = request.form.get("status", "Active").strip()

        if not policy_no or not name:
            return "❌ Policy number and name are required!", 400

        df = load_data()
        if policy_no in df["Policy_No"].astype(str).values:
            return "❌ Policy number already exists!", 400

        new = {"Policy_No": policy_no, "Name": name, "CNIC": cnic, "Valid_Till": valid_till, "Status": status}
        df = pd.concat([df, pd.DataFrame([new])], ignore_index=True)
        save_data(df)
        
        return render_template("success.html", 
                             message="New Policy Added Successfully!",
                             title="Policy Added",
                             links=[
                                 {"text": "Back to Chatbot", "url": "/"},
                                 {"text": "Add Another", "url": "/add"},
                                 {"text": "View All", "url": "/show"}
                             ])

    return render_template("add_policy.html")
@app.route("/show")
def show_policies():
    try:
        df = load_data()
        policies = df.to_dict('records')
        return render_template("show_policies.html", policies=policies)
    except Exception as e:
        return render_template("error.html", message=f"Error loading data: {e}")
@app.route("/edit/<policy_no>", methods=["GET", "POST"])
def edit_policy(policy_no):
    df = load_data()
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        cnic = request.form.get("cnic", "").strip()
        valid_till = request.form.get("valid_till", "").strip()
        status = request.form.get("status", "Active").strip()

        if not name:
            return "❌ Name is required!", 400

        df.loc[df["Policy_No"].astype(str) == policy_no, ["Name", "CNIC", "Valid_Till", "Status"]] = [name, cnic, valid_till, status]
        save_data(df)
        
        return render_template("success.html",
                             message="Policy Updated Successfully!",
                             title="Policy Updated",
                             links=[
                                 {"text": "Back to Policies", "url": "/show"},
                                 {"text": "Home", "url": "/"}
                             ])


    match = df[df["Policy_No"].astype(str) == policy_no]
    if match.empty:
        return render_template("error.html", message="Policy not found!"), 404
    
    row = match.iloc[0]
    return render_template("edit_policy.html",
                         policy_no=row['Policy_No'],
                         name=row['Name'],
                         cnic=row['CNIC'],
                         valid_till=row['Valid_Till'],
                         status=row['Status'])
@app.route("/delete/<policy_no>", methods=["POST"])
def delete_policy(policy_no):
    df = load_data()
    df = df[df["Policy_No"].astype(str) != policy_no]
    save_data(df)
    
    return render_template("success.html",
                         message="Policy Deleted Successfully!",
                         title="Policy Deleted",
                         links=[
                             {"text": "Back to Policies", "url": "/show"},
                             {"text": "Home", "url": "/"}
                         ])
if __name__ == "__main__":
    app.run(debug=True)



