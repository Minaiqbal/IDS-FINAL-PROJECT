function sendMessage() {
    let userInput = document.getElementById("user-input");
    let msg = userInput.value.trim();
    if (msg === "") return;

    let chatBox = document.getElementById("chat-box");
    chatBox.innerHTML += `<div><b>You:</b> ${msg}</div>`;

    fetch("/get", {
        method: "POST",
        body: new URLSearchParams({ msg: msg }),
        headers: { "Content-Type": "application/x-www-form-urlencoded" }
    })
    .then(res => res.text())
    .then(data => {
        chatBox.innerHTML += `<div><b>Bot:</b> ${data}</div>`;
        chatBox.scrollTop = chatBox.scrollHeight;
    });

    userInput.value = "";
}

